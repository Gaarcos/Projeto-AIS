﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using crud1Projeto.DAO;
using crud1Projeto.Models;

namespace crud1Projeto.Controllers
{
    public class PessoaController : Controller
    {
        public IActionResult Index()
        {
            PessoaDAO dao = new PessoaDAO();
            return View(dao.Listagem());
        }
        public IActionResult Form()
        {
            return View();
        }
        public IActionResult Create(PessoaViewModel pessoa)
        {
            try
            {
                PessoaDAO dao = new PessoaDAO();
                if (pessoa.Id == 0)
                {
                    dao.Inserir(pessoa);
                }
                else
                {
                    dao.Alterar(pessoa);
                }
                return RedirectToAction("Index");
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }
        public IActionResult Edit(int id)
        {
            try
            {
                PessoaDAO dao = new PessoaDAO();
                var pessoa = dao.Consulta(id);
                return View("Form", pessoa);
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }
        public IActionResult Delete(int id)
        {
            try
            {
                var dao = new PessoaDAO();
                dao.Excluir(id);
                return RedirectToAction("index");
            }
            catch (Exception erro)
            {
                return View("Error", new ErrorViewModel(erro.ToString()));
            }
        }
    }
}
