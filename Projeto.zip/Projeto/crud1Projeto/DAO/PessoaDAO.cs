﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using crud1Projeto.Models;

namespace crud1Projeto.DAO
{
    public class PessoaDAO
    {
        public void Inserir(PessoaViewModel f)
        {
            string sql =
            "insert into listagemPessoas(nome, telefone, apartamento, bloco, cpf, dataNascimento)" +
            "values (@nome, @telefone, @apartamento,@bloco, @cpf, @dataNascimento)";
            HelperDAO.ExecutaSQL(sql, CriaParametros(f));
        }
        public void Alterar(PessoaViewModel pessoa)
        {
            string sql =
            "update listagemPessoas set nome = @nome, " +
            "telefone = @telefone, " +
            "apartamento = @apartamento, " +
            "bloco = @bloco, " +
            "cpf = @cpf, " +
            "dataNascimento = @dataNascimento " +
            "where id = @id";
            HelperDAO.ExecutaSQL(sql, CriaParametros(pessoa));
        }
        private SqlParameter[] CriaParametros(PessoaViewModel f)
        {
            SqlParameter[] parametros = new SqlParameter[7];
            parametros[0] = new SqlParameter("id", f.Id);
            parametros[1] = new SqlParameter("nome", f.Nome);
            parametros[2] = new SqlParameter("telefone", f.Telefone);
            parametros[3] = new SqlParameter("apartamento", f.Apartamento);
            parametros[4] = new SqlParameter("bloco", f.Bloco);
            parametros[5] = new SqlParameter("cpf", f.Cpf);
            parametros[6] = new SqlParameter("dataNascimento", f.DataNascimento);
            return parametros;
        }
        public void Excluir(int id)
        {
            string sql = "delete listagemPessoas where id =" + id;
            HelperDAO.ExecutaSQL(sql, null);
        }
        private PessoaViewModel MontaPessoa(DataRow registro)
        {
            var a = new PessoaViewModel();
            a.Id = Convert.ToInt32(registro["id"]);
            a.Nome = registro["nome"].ToString();
            a.Telefone = registro["telefone"].ToString();
            a.Apartamento = Convert.ToInt32(registro["apartamento"]);
            a.Bloco = registro["bloco"].ToString();
            a.Cpf = registro["cpf"].ToString();
            a.DataNascimento = Convert.ToDateTime(registro["dataNascimento"]);
            return a;
        }
        public PessoaViewModel Consulta(int id)
        {
            string sql = "select * from listagemPessoas where id = " + id;
            DataTable tabela = HelperDAO.ExecutaSelect(sql, null);
            if (tabela.Rows.Count == 0)
                return null;
            else
                return MontaPessoa(tabela.Rows[0]);
        }
        public List<PessoaViewModel> Listagem()
        {
            List<PessoaViewModel> lista = new List<PessoaViewModel>();
            string sql = "select * from listagemPessoas order by nome";
            DataTable tabela = HelperDAO.ExecutaSelect(sql, null);
            foreach (DataRow registro in tabela.Rows)
                lista.Add(MontaPessoa(registro));
            return lista;
        }
    }
}
